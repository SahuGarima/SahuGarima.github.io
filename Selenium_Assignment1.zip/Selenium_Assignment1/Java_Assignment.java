package Selenium_Assignment1;

public class Java_Assignment 
{
	public static void main(String args[])
	{
		double amount = 8221.75, paise1=0.0, paise2=0.0;
		int two_thousand=0, one_thousand=0, five_hundred=0, two_hundred=0, hundred=0, fifty=0, twenty=0, ten=0, five=0, one=0;
		
		System.out.println("BEFORE Amount is    "+amount);
		
		while(amount > 0)
		{
			if(amount >= 2000)
			{
				amount = amount - 2000;
				two_thousand++;
				if(two_thousand > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 1000)

			{
				amount = amount - 1000;
				one_thousand++;
				if(one_thousand > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 500)
			{
				amount = amount - 500;
				five_hundred++;
				if(five_hundred > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;	
				}
			}
			else if(amount >= 200)
			{
				amount = amount - 200;
				two_hundred++;
				if(two_hundred > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 100)
			{
				amount = amount - 100;
				hundred++;
				if(hundred > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 50)
			{
				amount = amount - 50;
				fifty++;
				if(fifty > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 20)
			{
				amount = amount - 20;
				twenty++;
				if(twenty > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 10)
			{
				amount = amount - 10;
				ten++;
				if(ten > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 5)
			{
				amount = amount - 5;
				five++;
				if(five > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 1)
			{
				amount = amount - 1;
				one++;
				if(one > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 0.50)
			{
				amount = amount - 0.50;
				paise1++;
				if(paise1 > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
			else if(amount >= 0.25)
			{
				amount = amount - 0.25;
				paise2++;
				if(paise2 > 20)
				{
					System.out.println("Can not execute as counter increased by 20");
					break;
				}
			}
		}
		System.out.println("AFTER Amount is   "+amount);
		System.out.println("Counter of 2000   "+two_thousand);
		System.out.println("Counter of 1000   "+one_thousand);
		System.out.println("Counter of 500    "+five_hundred);
		System.out.println("Counter of 200    "+two_hundred);
		System.out.println("Counter of 100    "+hundred);
		System.out.println("Counter of 50     "+fifty);
		System.out.println("Counter of 20     "+twenty);
		System.out.println("Counter of 10     "+ten);
		System.out.println("Counter of 5      "+five);
		System.out.println("Counter of 1      "+one);
		System.out.println("Counter of 0.50   "+paise1);
		System.out.println("Counter of 0.25   "+paise2);
	}

}
