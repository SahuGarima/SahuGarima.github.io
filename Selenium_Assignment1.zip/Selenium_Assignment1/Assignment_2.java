package Selenium_Assignment1;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_2 
{
  WebDriver driver;
  String driverPath = "C://Users/USER/Documents/chromedriver_win32/chromedriver.exe";
  
  @BeforeTest
  public void browser_setup() 
  {
	  System.setProperty("webdriver.chrome.driver", driverPath);
	  driver = new ChromeDriver();
	  driver.get("https://virgoinnovations.com/Virgo/#/app/login");
	  
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
  }
  
  @Test
  public void login()
  {
	  WebElement email = driver.findElement(By.xpath("//*[@id=\"LoginID\"]"));
	  WebElement pass = driver.findElement(By.xpath("//*[@id=\"login-password\"]"));
	  WebElement login = driver.findElement(By.xpath("//*[@id=\"frmCaptcha\"]/div[5]/div/div/button/span"));
	  
	  email.sendKeys("Test@gmail.com");
	  //System.out.println(email.getText());
	  pass.sendKeys("test@123");
	  login.click();
	  
  }
  
  @AfterTest
  public void terminate()
  {
	  driver.close();
  }
}
