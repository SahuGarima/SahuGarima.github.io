package Selenium_Assignment1;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assignment_1 
{
	WebDriver driver;
	String driverPath = "C://Users/USER/Documents/chromedriver_win32/chromedriver.exe";
	
  @BeforeTest
  @Parameters("browser")
  public void Browser_setup(String browser)throws Exception
  {
	if(browser.equalsIgnoreCase("Chrome"))
	{
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
	
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://toolsqa.com/automation-practice-form/");
	}
	
	else if(browser.equalsIgnoreCase("InternetExplorer"))
	{
		System.setProperty("webdriver.ie.driver", "pathofIEdriver\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://toolsqa.com/automation-practice-form/");
	}
  }
  
  @Test(priority = 0)
  public void selenium_command() 
  {
	  System.out.println("Logged into browser");
	  
	  WebElement command_list = driver.findElement(By.xpath("//*[@id=\"selenium_commands\"]"));
	  Select sl = new Select (command_list);
	  sl.selectByVisibleText("Navigation Commands");
	  System.out.println("Selected Navigation Commands option from Selenium Command drop down box");
  }
  
  @Test(priority = 1)
  public void continents_listbox()
  {
	  WebElement ele_continents = driver.findElement(By.xpath("//*[@id=\"continents\"]"));
	  Select sl_continents = new Select(ele_continents);
	  sl_continents.selectByIndex(3);
	  System.out.println("Australiz selected using index");
	  
  }
  
  @Test(priority = 2)
  public void select_checkbox()
  {
	  WebElement chk_IDE = driver.findElement(By.xpath("//*[@id=\"tool-1\"]"));
	  WebElement chk_WebDriver = driver.findElement(By.xpath("//*[@id=\"tool-2\"]"));
	  
	  chk_IDE.click();
	  chk_WebDriver.click();
	  
	  System.out.println("Clicked on 2 check boxes");
	  
	  WebElement chk_MT = driver.findElement(By.xpath("//*[@id=\"profession-0\"]"));
	  WebElement chk_AT = driver.findElement(By.xpath("//*[@id=\"profession-1\"]"));
	  
	  chk_MT.click();
	  chk_AT.click();
	  
	  System.out.println("Clicked Manual & Automation Tester boxes");
	  	
  }
  
  @Test(priority = 3)
  public void download_files()
  {
	  WebDriverWait wait1 = new WebDriverWait(driver, 180);
	  WebElement download_link1 = wait1.until(ExpectedConditions.elementToBeClickable(By.linkText("Selenium Automation Hybrid Framework")));
	  
	  //WebElement download_link1 = driver.findElement(By.linkText("Selenium Automation Hybrid Framework"));
	  
	  download_link1.click();
	  System.out.println("Clicked on lin1");
	  
	  /*String source_location = download_link1.getAttribute("href");
	  String wget_cmd = "cmd /c C:\\Wget\\wget.exe -P D: --no-check-certificate " + source_location;
	  
	  try
		{
			Process exe = Runtime.getRuntime().exec(wget_cmd);
			int exeVal = exe.waitFor();
			System.out.println("Exit Value: "+exeVal);
		}catch(InterruptedException | IOException e)
		{
			System.out.println(e.toString());
		}*/
	  
	  WebDriverWait wait = new WebDriverWait(driver, 180);
	  WebElement download_link2 = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Test File to Download"))); 
	  
	  //WebElement download_link2 = driver.findElement(By.linkText("Test File To Download"));
	  
	  download_link2.click();
	  
	  System.out.println("Links are dowloaded...");
	  
  }
  
  @Test(priority = 4)
  public void upload_photo()
  {
	  WebElement ele_upload = driver.findElement(By.xpath("//*[@id=\"photo\"]"));
	  ele_upload.sendKeys("D:/Test_ScreenShot.png");
	  
	  System.out.println("Photo uploaded successfully");
  }
    
  @Test(priority = 5)
  public void data_input()
  {
	  WebElement ele_date = driver.findElement(By.id("datepicker"));
	  ele_date.sendKeys("07/07/1990");
	  System.out.println("Date entered");
	  
	  WebElement rdb_year = driver.findElement(By.id("exp-5"));
	  rdb_year.click();
	  System.out.println("Year of experience selected");
	  
	  WebElement gender = driver.findElement(By.id("sex-1"));
	  gender.click();
	  System.out.println("Gender selected");
	  
	  WebElement first_name = driver.findElement(By.name("firstname"));
	  WebElement last_name = driver.findElement(By.name("lastname"));
	  
	  first_name.sendKeys("Garima");
	  last_name.sendKeys("Sahu");
	  
	  System.out.println("First & Last name entered");
  }
  
  
  
  @AfterTest
  public void driver_terminate()
  {
	  driver.close();
  }
}
